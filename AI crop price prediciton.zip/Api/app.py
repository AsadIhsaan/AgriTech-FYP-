import pickle
from flask import Flask, request, jsonify
from flask_cors import CORS

# Initialize Flask app
app = Flask(__name__)
CORS(app)

# Load the trained model and encoders
try:
    with open('crop_price_model (2).pkl', 'rb') as f:
        model = pickle.load(f)
        print(f"✅ Loaded model type: {type(model)}")

    with open('crop_encoder (2).pkl', 'rb') as f:
        le_crop = pickle.load(f)

    with open('region_encoder (2).pkl', 'rb') as f:
        le_region = pickle.load(f)

except Exception as e:
    print("❌ Error loading model or encoders:", e)
    model = None
    le_crop = None
    le_region = None

@app.route('/predict', methods=['POST'])
def predict():
    print("📩 Received request:", request.get_json())

    if model is None or le_crop is None or le_region is None:
        return jsonify({'error': 'Model or encoders not loaded correctly.'}), 500

    try:
        data = request.get_json()

        # Required fields
        required_keys = ['crop', 'area']
        if not all(key in data for key in required_keys):
            return jsonify({'error': f'Missing keys. Required: {required_keys}'}), 400

        crop = data['crop']
        area = data['area']

        try:
            crop_encoded = le_crop.transform([crop])[0]
            area_encoded = le_region.transform([area])[0]
        except Exception as e:
            return jsonify({'error': f'Invalid crop or area value: {str(e)}'}), 400

        features = [crop_encoded, area_encoded]
        print("🔍 Final features to model:", features)

        prediction = model.predict([features])
        print("✅ Prediction made:", prediction)

        return jsonify({'prediction': round(float(prediction[0]), 2)})

    except Exception as e:
        print("❌ Exception during prediction:", e)
        return jsonify({'error': str(e)}), 500

# Run the app
if __name__ == '__main__':
    app.run(port=5000, debug=True)
