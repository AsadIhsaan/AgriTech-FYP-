const HARD_CODED_CATEGORIES = [
    { name: 'Fruits', description: 'Fresh fruits from the farm' },
    { name: 'Vegetables', description: 'Fresh and organic vegetables' },
    { name: 'Grains', description: 'High-quality grains and cereals' },
    { name: 'Dairy', description: 'Milk, cheese, and other dairy products' },
    { name: 'Poultry', description: 'Poultry items like eggs and chicken' }
  ];
  